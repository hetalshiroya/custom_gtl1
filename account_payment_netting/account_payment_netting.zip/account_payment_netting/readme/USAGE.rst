Given there are open invoices both receivable and payable,
and user decide to make payment on the diff.

- Open menu Accounting > Invoices to Netting
- Select multiple open invoices from the same partner
- Click on action "Register Payment", the wizard will show the diff amount
- Make payment as normal

This create Customer Payment if AR > AP, Supplier Payment otherwise.
