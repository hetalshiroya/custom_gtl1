This module allow net payment on AR/AP invoice from the same business partner.

**NOTE**: This module is influenced by account_netting,
but make it more user friendly when netting invoices.
While account netting require user to select manually the journal items to do netting
(which create netting journal entry), this module has a new menu "Invoices to netting"
allowing user to select both customer/supplier invoice to register payment.
